import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { getFirestore, doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';
import config from './firebase-config-module.js';

const form=document.querySelector('#loginForm');
const email=document.querySelector('#email');
const password=document.querySelector('#password');
const button=form?.querySelector('button[type="submit"]');
const output=document.querySelector('#loginMsg');
const setMessage=(text,good=false)=>{if(output){output.textContent=text;output.className='msg '+(good?'success':'')}};
const timeout=(promise,ms=18000)=>Promise.race([promise,new Promise((_,reject)=>setTimeout(()=>reject({code:'timeout',message:'انتهت مهلة الاتصال بخدمة Firebase.'}),ms))]);
const friendly=(e)=>{const c=e?.code||'',m=String(e?.message||'');if(c==='timeout')return'تعذر الاتصال بـ Firebase خلال المهلة. تحقق من الإنترنت ثم أعد المحاولة.';if(c==='auth/invalid-credential'||c==='auth/wrong-password'||c==='auth/user-not-found')return'البريد الإلكتروني أو كلمة المرور غير صحيحة.';if(c==='auth/invalid-email')return'اكتب بريدًا إلكترونيًا صحيحًا.';if(c==='auth/too-many-requests')return'تم إيقاف المحاولات مؤقتًا لكثرة المحاولات. انتظر قليلًا ثم حاول مرة أخرى.';if(c==='auth/network-request-failed')return'تعذر الاتصال بالإنترنت. تحقق من الشبكة.';if(c==='auth/unauthorized-domain')return'دومين الاستضافة غير مضاف في Firebase. أضفه من Authorized domains.';if(c==='auth/operation-not-allowed')return'تسجيل الدخول بالبريد غير مفعّل في Firebase Authentication.';if(c==='auth/api-key-not-valid'||/api.?key/i.test(m))return'مفتاح Firebase غير صحيح في ملف الإعدادات.';return m||'حدث خطأ غير متوقع أثناء تسجيل الدخول.'};

async function clearSession(){try{localStorage.clear();sessionStorage.clear();await signOut(auth).catch(()=>{});setMessage('تم تنظيف الجلسة. أعد المحاولة الآن.',true)}catch(e){setMessage('تعذر تنظيف الجلسة. امسح بيانات الموقع من المتصفح.')}}
let auth;
try{
  const app=initializeApp(config);auth=getAuth(app);const db=getFirestore(app);window.DAWATY_LOGIN_READY=true;
  document.body.classList.add('firebase-ready');
  document.querySelector('#togglePassword')?.addEventListener('click',()=>{const visible=password.type==='text';password.type=visible?'password':'text';document.querySelector('#togglePassword').textContent=visible?'إظهار':'إخفاء'});
  document.querySelector('#resetFirebaseSession')?.addEventListener('click',clearSession);
  onAuthStateChanged(auth,async user=>{if(!user)return;try{setMessage('تم التحقق من الحساب، جاري فتح لوحة العميل...',true);const snap=await timeout(getDoc(doc(db,'clients',user.uid)));const profile=snap.exists()?snap.data():{};location.replace(profile.role==='admin'?'admin.html':'client.html')}catch(e){await signOut(auth).catch(()=>{});setMessage('تم تسجيل الحساب لكن تعذر قراءة ملف العميل من Firestore. راجع قواعد Firestore أو أنشئ ملف العميل من لوحة الإدارة.')}});
  form?.addEventListener('submit',async e=>{e.preventDefault();if(!email.value.trim()||!password.value){setMessage('اكتب البريد وكلمة المرور أولًا.');return}button.disabled=true;setMessage('جاري الاتصال بخدمة الدخول...');try{await timeout(signInWithEmailAndPassword(auth,email.value.trim().toLowerCase(),password.value));}catch(err){setMessage(friendly(err));button.disabled=false}});
}catch(err){window.DAWATY_LOGIN_READY=false;setMessage('تعذر تشغيل Firebase. تأكد أن ملفات firebase-config-module.js وfirebase.js مرفوعة بجانب login.html.');console.error('Dawaty Firebase startup error',err)}
